package com.example.foodpro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
