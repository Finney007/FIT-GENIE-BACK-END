import 'package:flutter/cupertino.dart';

class FitnessScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Fitness Screen - Coming Soon',
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}

class NutritionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Nutrition Screen - Coming Soon',
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}